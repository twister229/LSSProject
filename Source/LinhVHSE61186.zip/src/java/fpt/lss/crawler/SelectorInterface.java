/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package fpt.lss.crawler;

/**
 *
 * @author HongLinh
 */
public interface SelectorInterface {
    //return list of tag a
    public String getListCategory();
    public String getListLaptop();
    public String getName();
    public String getWarranty();
    public String getAvatar();
    public String getSourceLink();
    public String getPrice();
    public String getHost();
    public String getListContent();
}
