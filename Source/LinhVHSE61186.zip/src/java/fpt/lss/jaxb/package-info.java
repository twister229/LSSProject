@javax.xml.bind.annotation.XmlSchema(namespace = "http://xml.netbeans.org/schema/lss_cpu", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package fpt.lss.jaxb;
